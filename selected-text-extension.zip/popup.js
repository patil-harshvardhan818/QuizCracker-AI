document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get("selectedText", (data) => {
    const text = data.selectedText || "No text selected yet.";
    // document.getElementById("selectedText").textContent = text;

    console.log(text);

    const apiKey = "AIzaSyCydqUCI5Xh50AQKyk22wBlRQau0rOseZk";

    fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `Explain the meaning of the word: "${text}" in simple language.`,
                },
              ],
            },
          ],
        }),
      }
    )
      .then((res) => res.json())
      .then((data) => {
        const textReply =
          data.candidates?.[0]?.content?.parts?.[0]?.text ||
          "No response from Gemini.";

        console.log(textReply); // it shows up here but doesn't below on the html thingy
        document.getElementById("selectedText").textContent = textReply;
      })
      .catch((error) => {
        console.error("Error:", error);
        document.getElementById("selectedText").textContent = error;
      });
  });
});
